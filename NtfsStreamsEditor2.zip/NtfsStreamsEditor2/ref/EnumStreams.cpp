// EnumStreams.cpp : Implementation of CEnumStreams
#include "stdafx.h"
#include "StrmExt.h"
#include "EnumStreams.h"
#include <shlwapi.h>

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "shlwapi.lib")

static TCHAR g_szFile[MAX_PATH];
static void RefreshStreams(HWND);
static void ShowHardLinkInfo(HWND);
static void DeleteStream(HWND);
static void CreateLinks(HWND);
static void EditStreams(HWND);
static void SelectionChanged(HWND);



/////////////////////////////////////////////////////////////////////////////
// CEnumStreams


/////////////////////////////////////////////////////////////////////////////
// Methods of IShellExtInit


// Initialize
HRESULT CEnumStreams::Initialize(LPCITEMIDLIST pidlFolder,
	LPDATAOBJECT lpdobj, HKEY hKeyProgID)
{
   if (lpdobj == NULL)
        return E_INVALIDARG;

   // Initialize common controls
   InitCommonControls();

   // Get the data as CF_HDROP   
   STGMEDIUM medium;
   FORMATETC fe = {CF_HDROP, NULL, DVASPECT_CONTENT, -1, TYMED_HGLOBAL};
   HRESULT hr = lpdobj->GetData(&fe, &medium);
   if (FAILED(hr))
        return E_INVALIDARG;

	// save the file name
    if (DragQueryFile((HDROP) medium.hGlobal, 0xFFFFFFFF, NULL, 0)==1) 
	{
		DragQueryFile((HDROP) medium.hGlobal, 0, m_szFile, 
			sizeof(m_szFile));

		// Is the volume NTFS?
		if (IsNTFS()) 
		{
			lstrcpy(g_szFile, m_szFile);
			hr = NOERROR;
		}
		else 
			hr = E_INVALIDARG;
    }
    else
        hr = E_INVALIDARG;

	ReleaseStgMedium(&medium);
    return hr;
}



/////////////////////////////////////////////////////////////////////////////
// Methods of IShellPropSheetExt 


// AddPages
HRESULT CEnumStreams::AddPages(LPFNADDPROPSHEETPAGE lpfnAddPage,
	LPARAM lParam)
{
	PROPSHEETPAGE psp;
	HPROPSHEETPAGE hPage;

	ZeroMemory(&psp, sizeof(PROPSHEETPAGE));
    psp.dwSize = sizeof(PROPSHEETPAGE);
    psp.dwFlags = PSP_USETITLE|PSP_DEFAULT;
    psp.hInstance = _Module.GetModuleInstance();
    psp.pszTemplate = MAKEINTRESOURCE(IDD_ENUMSTREAMS);
    psp.pszTitle = _T("Streams");
    psp.pfnDlgProc = (DLGPROC) PropPage_DlgProc;
    psp.lParam = (LPARAM) this;
    hPage = ::CreatePropertySheetPage(&psp);

    // add the page to the property sheet
    if (hPage != NULL)
        if (!lpfnAddPage(hPage, lParam))
		::DestroyPropertySheetPage(hPage);

    return NOERROR;
}


/////////////////////////////////////////////////////////////////////////////
// Helper Functions 


// Get volume information
BOOL CEnumStreams::IsNTFS()
{
	DWORD dwFlags=0;

	TCHAR pszBuf[MAX_PATH];
	lstrcpy(pszBuf, m_szFile);
	PathStripToRoot(pszBuf);
	GetVolumeInformation(pszBuf, NULL, 0, NULL, NULL, 
		&dwFlags, NULL, 0);

	return dwFlags & FILE_NAMED_STREAMS;
}


// STATIC: Dialog-procedure for the new page
BOOL CALLBACK CEnumStreams::PropPage_DlgProc(HWND hwnd, UINT uiMsg, WPARAM wParam,
    LPARAM lParam)
{
    switch(uiMsg) 
	{
		case WM_INITDIALOG:
			ShowHardLinkInfo(hwnd);
			RefreshStreams(hwnd);
			return TRUE;   
		
		case WM_COMMAND:
			if (LOWORD(wParam) == IDC_DELETE)
				DeleteStream(hwnd);
			if (LOWORD(wParam) == IDC_RUN)
				EditStreams(hwnd);
			if (LOWORD(wParam) == IDC_HLCREATE)
				CreateLinks(hwnd);
			if (LOWORD(wParam) == IDC_REFRESH)
			{
				RefreshStreams(hwnd);
				ShowHardLinkInfo(hwnd);
			}
			if (HIWORD(wParam) == LBN_SELCHANGE)
				SelectionChanged(hwnd);
			break;
    }
    return FALSE;
}


// STATIC: Helper function to initialize the property page
void RefreshStreams(HWND hwnd)
{
	HWND hwndList = GetDlgItem(hwnd, IDC_LIST);
	SendMessageW(hwndList, LB_RESETCONTENT, 0, 0);
	SetDlgItemText(hwnd, IDC_TEXT, _T(""));

	
	// Open the file
	HANDLE hfile;
	hfile = CreateFile(g_szFile, GENERIC_READ, 
		FILE_SHARE_READ, NULL, OPEN_EXISTING, 
		FILE_FLAG_BACKUP_SEMANTICS, NULL);
	if (hfile == INVALID_HANDLE_VALUE)
		return;

	// Prepare for execution
	LPVOID lpContext = NULL;
	WIN32_STREAM_ID sid;
	DWORD dwRead;
	WCHAR wszStreamName[MAX_PATH];

	// Enumerate the streams...
	BOOL bContinue = true;
	while (bContinue)
	{
		// Calculate the size of the variable length
		// WIN32_STREAM_ID structure
		ZeroMemory(&sid, sizeof(WIN32_STREAM_ID));
		ZeroMemory(wszStreamName, MAX_PATH);
		DWORD dwStreamHeaderSize = (LPBYTE)&sid.cStreamName - 
			   (LPBYTE)&sid+ sid.dwStreamNameSize;

		bContinue = BackupRead(hfile, (LPBYTE) &sid, 
			dwStreamHeaderSize, &dwRead, FALSE, FALSE, 
			&lpContext);
		
		if (!dwRead)
			break;
		if (dwRead != dwStreamHeaderSize)
			break;

		// At this point, we've read the header of the i.th
		// stream. What follows is the name of the stream and
		// next its content.
		
		// Read the stream name
		BackupRead(hfile, (LPBYTE) wszStreamName, 
			sid.dwStreamNameSize, &dwRead, 
			FALSE, FALSE, &lpContext);
		if (dwRead != sid.dwStreamNameSize)
			break;

		// A stream name is stored enclosed in a pair of colons
		// plus a $DATA default trailer. If the stream name is 
		// VersionInfo it's stored (and retrieved) as:
		// :VersionInfo:$DATA
		if (wcslen(wszStreamName))
		{
			LPWSTR pwsz = new WCHAR[MAX_PATH];
			lstrcpyW(pwsz, wszStreamName + sizeof(CHAR));
			LPWSTR wp = wcsstr(pwsz, L":");
			pwsz[wp-pwsz] = 0;
			lstrcpyW(wszStreamName, pwsz);
			delete [] pwsz;

			// Fill out the listbox
			SendMessageW(hwndList, LB_ADDSTRING, 0, (LPARAM)wszStreamName);
		}
		
		// Skip the stream body
		DWORD dw1, dw2;
		BackupSeek(hfile, sid.Size.LowPart, sid.Size.HighPart,  
			&dw1, &dw2, &lpContext);
	}

	CloseHandle(hfile);
}


// STATIC: Delete the currently selected stream
void DeleteStream(HWND hwnd)
{
	TCHAR szStreamName[MAX_PATH];
	HWND hwndList = GetDlgItem(hwnd, IDC_LIST);
	int nCurSel = SendMessage(hwndList, LB_GETCURSEL, 0, 0);
	SendMessage(hwndList, LB_GETTEXT, nCurSel, (LPARAM)szStreamName);

	// Prepare the fully-qualified stream name
	TCHAR szFileName[MAX_PATH*2];
	wsprintf(szFileName, _T("%s:%s"), g_szFile, szStreamName);

	
	TCHAR szBuf[1024];
	LoadString(_Module.GetModuleInstance(), 
		IDS_DELETE, szBuf, 1024);
	int rc = MessageBox(hwnd, szBuf, _T("Streams"), MB_YESNO);

	if (rc & IDYES) {
		DeleteFile(szFileName);
		RefreshStreams(hwnd);
	}
	return;
}



// STATIC: Retrieve and displays the content of the stream
void SelectionChanged(HWND hwnd)
{
	TCHAR szStreamName[MAX_PATH];
	HWND hwndList = GetDlgItem(hwnd, IDC_LIST);
	int nCurSel = SendMessage(hwndList, LB_GETCURSEL, 0, 0);
	SendMessage(hwndList, LB_GETTEXT, nCurSel, (LPARAM)szStreamName);

	// Prepare the fully-qualified stream name
	TCHAR szFileName[MAX_PATH*2];
	wsprintf(szFileName, _T("%s:%s"), g_szFile, szStreamName);

	// Read the stream 
	TCHAR szBuf[1024] = {0};
	HANDLE hfile = CreateFile(szFileName, GENERIC_READ, 
		FILE_SHARE_READ, NULL, OPEN_EXISTING, 
		FILE_FLAG_BACKUP_SEMANTICS, NULL);
	if (hfile == INVALID_HANDLE_VALUE)
		return;
	DWORD cb;

	ReadFile(hfile, szBuf, sizeof(szBuf), &cb, NULL);
	CloseHandle(hfile);


	// display the content
	SetDlgItemText(hwnd, IDC_TEXT, szBuf);
	return;
}



// STATIC: Run a VBS script for editing streams
void EditStreams(HWND hwnd)
{
	TCHAR fileName[MAX_PATH];
	GetModuleFileName(_Module.GetModuleInstance(), fileName, MAX_PATH);
	PathRemoveFileSpec(fileName);
	PathAddBackslash(fileName);
	lstrcat(fileName, _T("RWStream.vbs"));

	ShellExecute(NULL, _T("open"), fileName, g_szFile, NULL, SW_SHOW);
}


// STATIC: Run a VBS script for creating hard links
void CreateLinks(HWND hwnd)
{
	TCHAR fileName[MAX_PATH];
	GetModuleFileName(_Module.GetModuleInstance(), fileName, MAX_PATH);
	PathRemoveFileSpec(fileName);
	PathAddBackslash(fileName);
	lstrcat(fileName, _T("HardLinks.vbs"));

	ShellExecute(NULL, _T("open"), fileName, g_szFile, NULL, SW_SHOW);
}




// STATIC: Retrieve and display hard link information for the file
void ShowHardLinkInfo(HWND hwnd)
{
	// Open the file
	HANDLE hfile;
	hfile = CreateFile(g_szFile, GENERIC_READ, 
		FILE_SHARE_READ, NULL, OPEN_EXISTING, 
		FILE_FLAG_SEQUENTIAL_SCAN, NULL);
	if (hfile == INVALID_HANDLE_VALUE)
		return;
	
	// Get handle information
	BY_HANDLE_FILE_INFORMATION bhfi;
	BOOL b = GetFileInformationByHandle(hfile, &bhfi);
	CloseHandle(hfile);
	if (!b)		return;

	// Display info
	TCHAR buf[200];
	wsprintf(buf, _T("This file has %d hard link(s)."), 
		bhfi.nNumberOfLinks); 
	SetDlgItemText(hwnd, IDC_HLDESC, buf);
}
