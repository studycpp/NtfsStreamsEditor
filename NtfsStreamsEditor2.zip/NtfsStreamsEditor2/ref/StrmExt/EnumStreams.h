// EnumStreams.h : Declaration of the CEnumStreams

#ifndef __ENUMSTREAMS_H_
#define __ENUMSTREAMS_H_

#include "resource.h"					// main symbols
#include "comdef.h"						// GUIDs
#include "IShellExtInitImpl.h"			// IShellExtInit
#include "IShellPropSheetExtImpl.h"		// IShellPropSheetExt

/////////////////////////////////////////////////////////////////////////////
// CEnumStreams
class ATL_NO_VTABLE CEnumStreams : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CEnumStreams, &CLSID_EnumStreams>,
	public IShellPropSheetExtImpl,
	public IShellExtInitImpl,
	public IDispatchImpl<IEnumStreams, &IID_IEnumStreams, &LIBID_STRMEXTLib>
{
public:
	CEnumStreams()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_ENUMSTREAMS)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CEnumStreams)
	COM_INTERFACE_ENTRY(IEnumStreams)
	COM_INTERFACE_ENTRY(IShellExtInit)
	COM_INTERFACE_ENTRY(IShellPropSheetExt)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

public:
	STDMETHOD(Initialize) (LPCITEMIDLIST, LPDATAOBJECT, HKEY);
	STDMETHOD(AddPages) (LPFNADDPROPSHEETPAGE, LPARAM);

protected:
	BOOL IsNTFS();

// Static members
static	BOOL CALLBACK PropPage_DlgProc(HWND, UINT, WPARAM, LPARAM);

};

#endif //__ENUMSTREAMS_H_
