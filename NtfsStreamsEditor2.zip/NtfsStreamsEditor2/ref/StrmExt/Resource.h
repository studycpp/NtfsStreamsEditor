//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by StrmExt.rc
//
#define IDS_PROJNAME                    100
#define IDR_ENUMSTREAMS                 101
#define IDS_DELETE                      103
#define IDD_ENUMSTREAMS                 201
#define IDC_DESCTEXT                    201
#define IDI_ICON1                       202
#define IDC_LIST                        202
#define IDC_TEXT                        205
#define IDC_DELETE                      211
#define IDC_RUN                         212
#define IDC_REFRESH                     213
#define IDC_HLDESC                      214
#define IDC_HLCREATE                    215

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        203
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         217
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
