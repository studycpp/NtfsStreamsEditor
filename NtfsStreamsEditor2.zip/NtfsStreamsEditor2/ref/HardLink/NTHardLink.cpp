// NTHardLink.cpp : Implementation of CHardLink
#include "stdafx.h"
#include "HardLink.h"
#include "NTHardLink.h"

/////////////////////////////////////////////////////////////////////////////
// CHardLink


STDMETHODIMP CHardLink::CreateNewHardLink(BSTR bstrFileName, BSTR bstrExistingFileName)
{
	USES_CONVERSION;

	if (bstrFileName==NULL || bstrExistingFileName==NULL)
		return E_INVALIDARG;

	// Convert from BSTR to ANSI strings
	TCHAR pszFileName[MAX_PATH], pszExistingFileName[MAX_PATH];
	lstrcpy(pszFileName, OLE2T(bstrFileName));
	lstrcpy(pszExistingFileName, OLE2T(bstrExistingFileName));

	// Try to create the hard link to the specified file
	BOOL b;
	b = CreateHardLink(pszFileName, pszExistingFileName, NULL);
	if (b)
		return S_OK;
	return E_FAIL;
}
