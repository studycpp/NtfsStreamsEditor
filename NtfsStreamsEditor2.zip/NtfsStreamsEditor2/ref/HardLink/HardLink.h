/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Fri Dec 18 15:24:07 1998
 */
/* Compiler settings for D:\ARTICLES\Microsoft Internet Developer\Windows NT 5.0\SOURCE\HardLink\HardLink.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __HardLink_h__
#define __HardLink_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __INTHardLink_FWD_DEFINED__
#define __INTHardLink_FWD_DEFINED__
typedef interface INTHardLink INTHardLink;
#endif 	/* __INTHardLink_FWD_DEFINED__ */


#ifndef __NTHardLink_FWD_DEFINED__
#define __NTHardLink_FWD_DEFINED__

#ifdef __cplusplus
typedef class NTHardLink NTHardLink;
#else
typedef struct NTHardLink NTHardLink;
#endif /* __cplusplus */

#endif 	/* __NTHardLink_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __INTHardLink_INTERFACE_DEFINED__
#define __INTHardLink_INTERFACE_DEFINED__

/* interface INTHardLink */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_INTHardLink;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("7447E002-9683-11D2-9163-00C0DFE39736")
    INTHardLink : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CreateNewHardLink( 
            BSTR szFileName,
            BSTR szExistingFileName) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct INTHardLinkVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            INTHardLink __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            INTHardLink __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            INTHardLink __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            INTHardLink __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            INTHardLink __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            INTHardLink __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            INTHardLink __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CreateNewHardLink )( 
            INTHardLink __RPC_FAR * This,
            BSTR szFileName,
            BSTR szExistingFileName);
        
        END_INTERFACE
    } INTHardLinkVtbl;

    interface INTHardLink
    {
        CONST_VTBL struct INTHardLinkVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define INTHardLink_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define INTHardLink_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define INTHardLink_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define INTHardLink_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define INTHardLink_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define INTHardLink_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define INTHardLink_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define INTHardLink_CreateNewHardLink(This,szFileName,szExistingFileName)	\
    (This)->lpVtbl -> CreateNewHardLink(This,szFileName,szExistingFileName)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE INTHardLink_CreateNewHardLink_Proxy( 
    INTHardLink __RPC_FAR * This,
    BSTR szFileName,
    BSTR szExistingFileName);


void __RPC_STUB INTHardLink_CreateNewHardLink_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __INTHardLink_INTERFACE_DEFINED__ */



#ifndef __HARDLINKLib_LIBRARY_DEFINED__
#define __HARDLINKLib_LIBRARY_DEFINED__

/* library HARDLINKLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_HARDLINKLib;

EXTERN_C const CLSID CLSID_NTHardLink;

#ifdef __cplusplus

class DECLSPEC_UUID("7447E003-9683-11D2-9163-00C0DFE39736")
NTHardLink;
#endif
#endif /* __HARDLINKLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
