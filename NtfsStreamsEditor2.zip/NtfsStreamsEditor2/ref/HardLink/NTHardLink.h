// NTHardLink.h : Declaration of the CHardLink

#ifndef __NTHARDLINK_H_
#define __NTHARDLINK_H_

#include "resource.h"       // main symbols


/////////////////////////////////////////////////////////////////////////////
// CHardLink
class ATL_NO_VTABLE CHardLink : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CHardLink, &CLSID_NTHardLink>,
	public IDispatchImpl<INTHardLink, &IID_INTHardLink, &LIBID_HARDLINKLib>
{
public:
	CHardLink()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_NTHARDLINK)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CHardLink)
	COM_INTERFACE_ENTRY(INTHardLink)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// INTHardLink
public:
	STDMETHOD(CreateNewHardLink)(BSTR szFileName, BSTR szExistingFileName);
};

#endif //__NTHARDLINK_H_
