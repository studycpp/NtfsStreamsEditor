/////////////////////////////////////////////////////////////
// WSH JScript file
//
// Create hard links for the specified files
// Requires Windows 2000
// Usage:  TESTHL  new_file  existing_file
//

// Two arguments needed
if (WScript.Arguments.Length != 2) 
   WScript.Quit();

// Literals
var L_NO_HL_CREATED = "Unable to create hard link.";

// Create the object
var oHL = WScript.CreateObject( "HardLink.Object.1" );

// Get the arguments from the command line
var sNewFile = WScript.Arguments.Item(0)
var sExistingFile = WScript.Arguments.Item(1)

// Try to create the hardlink
try {
bResult = oHL.CreateNewHardLink(sNewFile, sExistingFile);
}
catch e {
   WScript.Echo(L_NO_HL_CREATED); }

if (bResult == 0)
   WScript.Echo(L_NO_HL_CREATED);
WScript.Quit();
